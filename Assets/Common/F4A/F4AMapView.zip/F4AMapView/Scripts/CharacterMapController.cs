﻿using UnityEngine;
using System.Collections;

namespace com.F4A.MobileThird
{
    public class CharacterMapController : MonoBehaviour
    {
    }
}
