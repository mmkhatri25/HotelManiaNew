﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace com.F4A.MobileThird
{
	public class SmartMapViewConfig : SingletonMono<SmartMapViewConfig> {
		public int DefaultLife = 5;
		public int gemDefault = 10;
	}
}